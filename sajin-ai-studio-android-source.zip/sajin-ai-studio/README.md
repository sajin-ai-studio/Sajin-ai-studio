# SAJIN AI STUDIO — Android cloud-build starter

This is the SAJIN AI STUDIO front-end prototype packaged for Android using Capacitor. The GitHub Actions workflow builds a debug APK in the cloud, so an Android phone can be used to download the APK without installing Android Studio locally.

## Build the APK using only an Android phone

1. Sign in to GitHub in your phone browser and create a **public** repository named `sajin-ai-studio` (public repositories can use standard GitHub-hosted runners within the applicable free limits).
2. Upload the contents of this project to the repository. Make sure `.github/workflows/android-apk.yml` is included. If the GitHub mobile upload page hides dot-folders, use GitHub's web interface in desktop mode or create the workflow file directly in the repository.
3. Open the repository's **Actions** tab.
4. Select **Build SAJIN AI STUDIO APK**.
5. Tap **Run workflow** and wait for the run to finish successfully.
6. Open the completed run and download the artifact named `sajin-ai-studio-debug-apk`. Extract the ZIP; inside is `app-debug.apk`.
7. Open `app-debug.apk` on your Android phone and allow installation from that source if Android asks.

## Important

- This produces a **debug APK for testing**, not a Play Store release-signed APK.
- The current app is a front-end prototype. The Generate button is a demo notice; it does not create real AI videos yet.
- The displayed credits are demo credits, not redeemable or connected to billing.
- Real video generation requires a backend and a video provider API. Keep provider API keys on the server; never put them in this app.
- Do not add secrets or API keys to a public repository.
