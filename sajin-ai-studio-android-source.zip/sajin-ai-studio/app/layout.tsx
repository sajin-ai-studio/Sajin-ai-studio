import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'SAJIN AI STUDIO', description: 'Create cinematic AI videos from text and images.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
