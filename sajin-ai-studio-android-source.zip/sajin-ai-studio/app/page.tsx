'use client';
import { useState } from 'react';
import { Clapperboard, ImagePlus, Video, WandSparkles, LayoutDashboard, FolderOpen, Coins, Settings, Play, ChevronDown, Sparkles, UploadCloud } from 'lucide-react';

type Mode = 'Text to video' | 'Image to video';
export default function Home() {
  const [mode, setMode] = useState<Mode>('Text to video');
  const [prompt, setPrompt] = useState('A cinematic drone shot flying over the beautiful coastline of Zanzibar at golden hour...');
  const [model, setModel] = useState('Choose an AI model');
  const [ratio, setRatio] = useState('16:9');
  const [duration, setDuration] = useState('5 seconds');
  const [file, setFile] = useState('');
  const [notice, setNotice] = useState('');
  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">S</div><div><b>SAJIN</b><span>AI STUDIO</span></div></div>
      <div className="side-label">WORKSPACE</div>
      <a className="nav active"><LayoutDashboard size={18}/> Dashboard</a>
      <a className="nav"><Clapperboard size={18}/> AI Video Generator</a>
      <a className="nav"><FolderOpen size={18}/> My Creations</a>
      <div className="side-label tools-label">ACCOUNT</div>
      <a className="nav"><Coins size={18}/> Credits & Plans</a>
      <a className="nav"><Settings size={18}/> Settings</a>
      <div className="credit-card"><div className="credit-top"><Coins size={17}/><span>YOUR CREDITS</span></div><strong>100 <small>credits</small></strong><div className="progress"><i/></div><p>Starter demo balance</p><button className="upgrade" onClick={()=>setNotice('Credit plans will be connected when billing is configured.')}>Explore plans <span>↗</span></button></div>
      <div className="profile"><div className="avatar">S</div><div><b>Sajin Creator</b><span>Free account</span></div><span className="dots">•••</span></div>
    </aside>
    <section className="main">
      <header className="topbar"><div className="crumb">Workspace <span>/</span> <b>AI Video Generator</b></div><div className="top-actions"><span className="status-dot"/> All systems ready <div className="top-avatar">S</div></div></header>
      <div className="content">
        <div className="welcome"><div><div className="eyebrow"><Sparkles size={14}/> YOUR CREATIVE AI WORKSPACE</div><h1>Make something <em>unreal.</em></h1><p>Turn your ideas into extraordinary videos with AI.</p></div><div className="welcome-chip"><WandSparkles size={16}/> Create without limits</div></div>
        <div className="workspace-grid">
          <div className="generator panel">
            <div className="panel-heading"><div><h2>Create a video</h2><p>Describe your vision. Let AI bring it to life.</p></div><span className="beta">BETA</span></div>
            <div className="mode-switch"><button className={mode==='Text to video'?'selected':''} onClick={()=>{setMode('Text to video');setNotice('')}}><Video size={17}/> Text to video</button><button className={mode==='Image to video'?'selected':''} onClick={()=>{setMode('Image to video');setNotice('')}}><ImagePlus size={17}/> Image to video</button></div>
            {mode==='Image to video' && <label className="upload"><UploadCloud size={24}/><b>{file || 'Upload an image'}</b><span>PNG or JPG · Image upload preview only</span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setFile(e.target.files?.[0]?.name || '')}/></label>}
            <label className="field-label">YOUR PROMPT <span>Be descriptive for best results</span></label>
            <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Describe the video you want to create..."/>
            <div className="prompt-foot"><span>{prompt.length} characters</span><button onClick={()=>setPrompt('Cinematic, ultra-realistic drone footage, smooth camera movement, golden hour lighting, highly detailed, professional film quality.') }><WandSparkles size={14}/> Enhance prompt</button></div>
            <div className="settings-row"><label><span>AI MODEL</span><select value={model} onChange={e=>setModel(e.target.value)}><option>Choose an AI model</option><option>Kling (API required)</option><option>Google Veo (API required)</option><option>Runway (API required)</option></select></label><label><span>ASPECT RATIO</span><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>16:9</option><option>9:16</option><option>1:1</option><option>4:5</option></select></label><label><span>DURATION</span><select value={duration} onChange={e=>setDuration(e.target.value)}><option>5 seconds</option><option>10 seconds</option><option>15 seconds</option></select></label></div>
            <button className="generate" onClick={()=>setNotice('This is the working UI prototype. Connect an AI video API and server-side credits before enabling real generation.')}><Sparkles size={18}/> Generate video <span>→</span></button>
            {notice && <div className="notice">{notice}</div>}
            <p className="fineprint">Generation uses credits. Actual model availability, pricing and duration depend on the connected provider.</p>
          </div>
          <div className="right-column">
            <div className="preview panel"><div className="preview-head"><h3>Preview canvas</h3><span>LIVE PREVIEW</span></div><div className="preview-art"><div className="orb orb-one"/><div className="orb orb-two"/><div className="preview-center"><div className="play-circle"><Play size={23} fill="currentColor"/></div><b>Your next creation starts here</b><span>Your generated video will appear here</span></div><div className="grid-lines"/></div><div className="preview-bottom"><span><i/> Ready for your idea</span><span>SAJIN AI</span></div></div>
            <div className="quick panel"><h3>Quick start</h3><button onClick={()=>{setMode('Text to video');setPrompt('A smooth cinematic drone reveal of a modern luxury villa surrounded by tropical gardens at sunset.');}}><span className="quick-icon purple"><Video size={17}/></span><span><b>Text to video</b><small>Start with a simple idea</small></span><span className="arrow">↗</span></button><button onClick={()=>{setMode('Image to video');setPrompt('Animate this image with natural cinematic camera movement, realistic lighting and subtle environmental motion.');}}><span className="quick-icon blue"><ImagePlus size={17}/></span><span><b>Animate an image</b><small>Bring a still image to life</small></span><span className="arrow">↗</span></button></div>
          </div>
        </div>
        <div className="bottom-note"><Sparkles size={14}/> Built for creators, dreamers and storytellers. <span>SAJIN AI STUDIO © 2026</span></div>
      </div>
    </section>
  </main>;
}
