import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.sajin.aistudio',
  appName: 'SAJIN AI STUDIO',
  webDir: 'out',
  bundledWebRuntime: false,
  backgroundColor: '#090812',
};
export default config;
